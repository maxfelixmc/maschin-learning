package argus_ai;

import java.io.IOException;

public class mainShapgen {

	public static void main(String[] args) {
		
		ShapeImageGenerator shap = new ShapeImageGenerator();
		
		try {
			shap.generateShapeImages(50, 50, 50, "C:\\Users\\felix\\eclipse-workspace\\argus_ai\\src\\shaps", "kreis");
			shap.generateShapeImages(50, 50, 50, "C:\\Users\\felix\\eclipse-workspace\\argus_ai\\src\\shaps", "quadrat");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("hallo");
		}

	}

}
