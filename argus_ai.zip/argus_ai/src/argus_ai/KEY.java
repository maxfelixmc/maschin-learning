package argus_ai;

public class KEY {
	protected static String secretKey = "cehwijpqfij4ovpqjmi49ov-032u9iff";
}
